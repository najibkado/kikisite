<?php

use Illuminate\Http\Request;
use App\User;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('/register', 'Api\AuthContorller@register');
Route::post('/login', 'Api\AuthContorller@login');
Route::put('/updatephone', 'Api\AuthContorller@updatePhone')->middleware('auth:api');
Route::post('/complete-registration', 'Api\AuthContorller@completeRegistration')->middleware('auth:api');
Route::get('/posts', 'Api\PostController@index')->middleware('auth:api');
Route::post('/post', 'Api\PostController@store')->middleware('auth:api');
Route::delete('/delete-post/{id}', 'Api\PostController@destroy')->middleware('auth:api');
Route::get('/like-post/{id}', 'Api\LikeController@storePostLikes')->middleware('auth:api');
Route::get('/like-comment/{id}', 'Api\LikeController@storeCommentLikes')->middleware('auth:api');
Route::get('/like-story-comment/{id}', 'Api\LikeController@storeStoryCommentLikes')->middleware('auth:api');
Route::post('comment', 'Api\CommentController@store')->middleware('auth:api');
Route::post('story-comment', 'Api\CommentController@storeStoryComment')->middleware('auth:api');
Route::post('comment-on-comment', 'Api\CommentController@commentOnComment')->middleware('auth:api');
Route::get('/comments/{postId}', 'Api\CommentController@index')->middleware('auth:api');
Route::get('/comment-details/{comment}', 'Api\CommentController@show')->middleware('auth:api');
Route::post('/profile/update', 'Api\ProfileController@update')->middleware('auth:api');
Route::get('/profile/{id}', 'Api\ProfileController@index')->middleware('auth:api');
Route::get('/follow/{user}', 'Api\FollowsController@store')->middleware('auth:api');
Route::get('/search/{user}', 'Api\UserController@search')->middleware('auth:api');
Route::get('/check-username/{username}', 'Api\UserController@checkUsername')->middleware('auth:api');
Route::get('/not-following', 'Api\UserController@index')->middleware('auth:api');
Route::get('/stories', 'Api\StoryController@index')->middleware('auth:api');
Route::post('/story', 'Api\StoryController@store')->middleware('auth:api');
Route::get('/like-story/{id}', 'Api\LikeController@storeStoryLikes')->middleware('auth:api');
Route::get('/view-story/{id}', 'Api\ViewsController@storeStoryViews')->middleware('auth:api');
Route::get('/chats', 'Api\ChatController@index')->middleware('auth:api');
Route::get('/chat/{id}', 'Api\ChatController@show')->middleware('auth:api');
Route::post('/send-chat', 'Api\ChatController@store')->middleware('auth:api');